package com.lms.app.service;

import com.lms.app.entity.Manager;
import com.lms.app.exception.LeaveManagementSystemException;

public interface ManagerService {
	
	
	public Manager registerManager(Manager manager);
//	public Integer updateLeaveBalance(Integer empId, Integer leavesAvailable) throws LeaveManagementSystemException;
//	public Integer getLeaveBalance(Integer empId) throws LeaveManagementSystemException;

}

