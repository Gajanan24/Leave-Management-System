package com.lms.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.app.entity.Employee;
import com.lms.app.entity.Manager;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.repository.EmployeeRepository;
import com.lms.app.repository.LeaveRepository;
import com.lms.app.repository.ManagerRepository;

@Service
public class ManagerServiceImpl implements ManagerService {
	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private LeaveRepository leaveRepository;
	@Autowired
	private ManagerRepository managerRepository;
	
	
	
	

//	@Override
//	public Integer updateLeaveBalance(Integer empId, Integer leavesBalance) throws LeaveManagementSystemException {
//		Optional<Employee> optionalEmployee= employeeRepository.findById(empId);
//		if(optionalEmployee.isPresent()) {
//			Employee employee=optionalEmployee.get();
//			employee.setLeaveBalance(leavesBalance);
//			return leavesBalance;
//		}
//		else {
//			throw new LeaveManagementSystemException("Employee not found ");
//		}
//	}
	

	@Override
	public Manager registerManager(Manager manager) {
		
		return managerRepository.save(manager);
	}


//	@Override
//	public Integer getLeaveBalance(Integer empId) throws LeaveManagementSystemException {
//		  Optional<Employee> optionalEmployee= employeeRepository.findById(empId);
//		  if(optionalEmployee.isPresent()) {
//		   Employee employee=optionalEmployee.get();
//			return  employee.getLeaveBalance();
//			  
//		  }
//		  else {
//			  throw new LeaveManagementSystemException("Employee not found with Id:  "+ empId);
//		  }
//	}
//	
	

}
