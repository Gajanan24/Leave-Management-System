package com.lms.app.service;

import com.lms.app.entity.Employee;
import com.lms.app.exception.LeaveManagementSystemException;

public interface EmployeeService {
	
	Employee addEmployee(Employee addEmployee);
	 
	  Employee getEmployeeById(Integer empid) throws LeaveManagementSystemException;
	  
	  Employee updatEmployee (Employee updateEmployee);
	 
	  Employee deletEmployeeById(Integer empid);

	  
	
	

}
