package com.lms.app.exception;

public class LeaveManagementSystemException extends Exception{
	
	public LeaveManagementSystemException(String message) {
		super(message);
	}

}
