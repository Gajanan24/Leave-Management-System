package com.lms.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lms.app.entity.Employee;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/employee")
	public Employee registerEmployee(@RequestBody Employee employee) {
		
		return employeeService.addEmployee(employee);
	}
	
	@GetMapping("/employee/{empId}")
	public Employee getEmployeeByID(@PathVariable("empId") Integer empId) throws LeaveManagementSystemException {
		
		return employeeService.getEmployeeById(empId);
	}
	@PutMapping("/employee")
	public Employee updatEmployee(@RequestBody Employee employee) {
		return employeeService.updatEmployee(employee);
		
	}
	
	
	

}
