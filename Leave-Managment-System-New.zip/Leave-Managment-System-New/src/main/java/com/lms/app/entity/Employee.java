package com.lms.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer empId;
	private String name;
	private String email;
	@JsonProperty(access = Access.READ_ONLY)
	private Integer leaveEntitlement = 24; // default value for leave entitlement is 24

	
	public Employee(Integer empId, String name, String email) {
		super();
		this.empId = empId;
		this.name = name;
		this.email = email;
		
	}
	public Employee() {
		super();
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public Integer getLeaveEntitlement() {
		return leaveEntitlement;
	}
	
	public void setLeaveEntitlement(Integer leaveEntitlement) {
		this.leaveEntitlement = leaveEntitlement;
	}
	

}
