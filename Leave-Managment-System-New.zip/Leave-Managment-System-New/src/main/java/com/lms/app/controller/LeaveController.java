package com.lms.app.controller;

import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lms.app.entity.Leave;
import com.lms.app.entity.LeaveType;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.service.LeaveService;

@RestController
public class LeaveController {
	@Autowired
	private LeaveService leaveService;

	@PostMapping("/leave")
	public void applyLeave(@RequestParam Integer empId,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam String reason) throws LeaveManagementSystemException {
		leaveService.applyLeave(empId, startDate, endDate, reason);

	}
	@DeleteMapping("/leave/{empId}/{id}")
	public void cancelLeave(@RequestParam Integer empId, @RequestParam Integer leaveId) throws LeaveManagementSystemException {
		leaveService.cancelLeave(empId, leaveId);
		
	}

	
	@GetMapping("/{empId}/leavebalance")
	public Integer getLeaveBalance(@PathVariable ("empId") Integer empId, 
	                                                @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) throws LeaveManagementSystemException {
	    int leaveBalance = leaveService.getLeaveBalance(empId, date);
	    return leaveBalance;
	}

}
