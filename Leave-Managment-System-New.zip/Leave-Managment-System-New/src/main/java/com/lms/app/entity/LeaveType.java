package com.lms.app.entity;

public enum LeaveType {
	
	VACATION,UNPAID_LEAVE,SICK_LEAVE;

}
