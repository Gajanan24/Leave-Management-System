package com.lms.app.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.app.entity.Employee;
import com.lms.app.entity.Leave;
import com.lms.app.entity.LeaveType;
import com.lms.app.entity.Status;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.repository.EmployeeRepository;
import com.lms.app.repository.LeaveRepository;

import net.bytebuddy.agent.builder.AgentBuilder.InitializationStrategy.SelfInjection.Eager;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	private LeaveRepository leaveRepository;
	@Autowired
	private EmployeeRepository employeeRepository;
	
	private static final int MAX_CARRY_FORWARD_LEAVES = 2;
	private static final int MAX_LEAVES_PER_MONTH = 2;
	private static final int MAX_LEAVES_PER_YEAR = 24;


	@Override
	public void cancelLeave(Integer empId, Integer leaveId) throws LeaveManagementSystemException {

		Optional<Leave> opLeave = leaveRepository.findById(leaveId);
		Leave leave = opLeave.get();
		Employee employee = leave.getEmployee();
		if (opLeave.isPresent() && leave.getEmployee().getEmpId().equals(empId)) {

			if (leave.getStatus().equals(Status.PENDING.toString())) {
				
				leave.setStatus(Status.CANCELLED.toString());
				leaveRepository.save(leave);
			} else {
				throw new LeaveManagementSystemException("Can't delete leave with status: " + leave.getStatus());
			}

		} else
			throw new LeaveManagementSystemException("Leave canot cancelled");

	}

	@Override
	public int calculateDaysApplied(LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub

		int days = 0;
		LocalDate date = startDate;
		while (!date.isAfter(endDate)) {
			if (date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY) {
				days++;
			}
			date = date.plusDays(1);
		}
		return days;

	}

//	@Override
//	public void applyLeave(Integer empId, LocalDate startDate, LocalDate endDate, String reason)
//			throws LeaveManagementSystemException {
//		Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//		if (optionalEmployee.isPresent()) {
//			Employee employee = optionalEmployee.get();
//			int daysApplied = calculateDaysApplied(startDate, endDate);
////			if (daysApplied > employee.getLeavesAvailable()) {
////				throw new RuntimeException("Insufficient leaves available");
////			}
////			employee.setLeavesAvailable(employee.getLeavesAvailable() - daysApplied);
//
////			employeeRepository.save(employee);
//
////			int leavesThisMonth = getLeavesThisMonth(empId);
////			if (leavesThisMonth + daysApplied > 2) {
////				throw new LeaveManagementSystemException("Maximum 2 leaves can be applied in a month");
////			}
//			
//			 // Get the leaves applied in the current month
////	        LocalDate firstDayOfMonth = LocalDate.now().withDayOfMonth(1);
////	        LocalDate lastDayOfMonth = firstDayOfMonth.with(TemporalAdjusters.lastDayOfMonth());
////	        List<Leave> leavesThisMonth = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, firstDayOfMonth, lastDayOfMonth);
////
////	        // Check if the number of leaves applied in the current month is already 2
////	        if (leavesThisMonth.stream().mapToInt(Leave::getNoOfDays).sum() + daysApplied > 2) {
////	            throw new LeaveManagementSystemException("Maximum 2 leaves can be applied in a month");
////	        }
//			
//			 // Get leaves applied in current month
//	        LocalDate firstDayOfMonth = LocalDate.now().withDayOfMonth(1);
//	        LocalDate lastDayOfMonth = LocalDate.now().withDayOfMonth(LocalDate.now().lengthOfMonth());
//	        List<Leave> leavesThisMonth = leaveRepository.findLeavesByEmployeeNoAndDateRange(
//	            empId, firstDayOfMonth, lastDayOfMonth);
//	        
//	        // Calculate total leaves applied in current month
//	        int leavesAppliedThisMonth = leavesThisMonth.stream()
//	            .mapToInt(Leave::getNoOfDays)
//	            .sum();
//	        
//	        // Check if leaves applied in current month exceed the limit
//	        if (leavesAppliedThisMonth + daysApplied > 2) {
//	            throw new LeaveManagementSystemException("Maximum 2 leaves can be applied in a month");
//	        }
//
//			Leave leave = new Leave();
//            leave.setFromDate(startDate);
//	        leave.setToDate(endDate);
//			leave.setStatus(Status.PENDING.toString());
//			leave.setReason(reason);
//			leave.setEmployee(employee);
//			leaveRepository.save(leave);
//
//		} else {
//			throw new RuntimeException("Employee not found");
//		}
//
//		}
	
	
//	@Override
//	public void applyLeave(Integer empId, LocalDate startDate, LocalDate endDate, String reason) throws LeaveManagementSystemException {
//	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//	    if (optionalEmployee.isPresent()) {
//	        Employee employee = optionalEmployee.get();
//	        int daysApplied = calculateDaysApplied(startDate, endDate);
//
//	        // Calculate unused leaves from previous months
//	        LocalDate startMonth = startDate.withDayOfMonth(1);
//	        LocalDate endMonth = endDate.with(TemporalAdjusters.lastDayOfMonth());
//
//	      
//	        List<Leave> unusedLeaves = leaveRepository.findUnusedLeavesByEmployeeNoAndDateRange(empId, startMonth, endDate);
//	        int totalUnusedLeaves = unusedLeaves.stream()
//	                .filter(leave -> leave.getStatus() != Status.CANCELLED.toString() && leave.getStatus() != Status.REJECTED.toString())
//	                .mapToInt(Leave::getNoOfDays)
//	                .sum();
//
//
//	        // Calculate maximum leaves that can be applied
//	        int maxLeaves = totalUnusedLeaves + MAX_LEAVES_PER_MONTH;
//
//	        // Check if leaves applied exceed the limit
//	        if (daysApplied > maxLeaves) {
//	            throw new LeaveManagementSystemException("Maximum " + maxLeaves + " leaves can be applied");
//	        }
//
//	        // Save the leave application
//	        Leave leave = new Leave();
//	        leave.setFromDate(startDate);
//	        leave.setToDate(endDate);
//	        leave.setStatus(Status.PENDING.toString());
//	        leave.setReason(reason);
//	        leave.setEmployee(employee);
//	        leaveRepository.save(leave);
//
//	    } else {
//	        throw new RuntimeException("Employee not found");
//	    }
//	}
	
	
	@Override
	public void applyLeave(Integer empId, LocalDate startDate, LocalDate endDate, String reason) throws LeaveManagementSystemException {
	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
	    if (optionalEmployee.isPresent()) {
	        Employee employee = optionalEmployee.get();
	        int daysApplied = calculateDaysApplied(startDate, endDate);

	        // Calculate unused leaves from previous months
	        LocalDate startMonth = LocalDate.of(startDate.getYear(), startDate.getMonth(), 1);
	        List<Leave> unusedLeaves = leaveRepository.findUnusedLeavesByEmployeeNoAndDateRange(empId, startMonth, endDate);
	        int totalUnusedLeaves = 0;
	        for (int i = 1; i <= 12; i++) {
	            int monthLeaves = 2;
	            if (i == startDate.getMonthValue()) {
	                monthLeaves -= startDate.getDayOfMonth() - 1;
	            }
	            if (i == endDate.getMonthValue()) {
	                monthLeaves -= endDate.lengthOfMonth() - endDate.getDayOfMonth();
	            }
	            for (Leave leave : unusedLeaves) {
	                if (leave.getFromDate().getMonthValue() == i) {
	                    monthLeaves += leave.getNoOfDays();
	                }
	            }
	            totalUnusedLeaves += Math.max(monthLeaves, 0);
	            if (totalUnusedLeaves >= MAX_LEAVES_PER_YEAR) {
	                break;
	            }
	        }

	        // Check if leaves applied exceed the limit
	        if (daysApplied > totalUnusedLeaves) {
	            throw new LeaveManagementSystemException("Maximum " + totalUnusedLeaves + " leaves can be applied");
	        }

	        // Save the leave application
	        Leave leave = new Leave();
	        leave.setFromDate(startDate);
	        leave.setToDate(endDate);
	        leave.setStatus(Status.PENDING.toString());
	        leave.setReason(reason);
	        leave.setEmployee(employee);
	        leaveRepository.save(leave);

	    } else {
	        throw new RuntimeException("Employee not found");
	    }
	}






	



	
	
//	private int getLeavesThisMonth(Integer empId) {
//	    LocalDate now = LocalDate.now();
//	    LocalDate startOfMonth = now.withDayOfMonth(1);
//	    LocalDate endOfMonth = now.withDayOfMonth(now.lengthOfMonth());
//	    List<Leave> leavesThisMonth = leaveRepository.findByEmployeeNoAndStartDateBetween(empId, startOfMonth, endOfMonth);
//	    return leavesThisMonth.stream().mapToInt(Leave::getNoOfDays).sum();
//	}

	
	@Override
	public int getLeavesThisMonth(Integer empId) {
		LocalDate today = LocalDate.now();
		LocalDate startDate = today.withDayOfMonth(1);
		LocalDate endDate = today.withDayOfMonth(today.lengthOfMonth());
		List<Leave> leavesThisMonth = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, startDate, endDate);

		int sum = 0;
		for (Leave leave : leavesThisMonth) {
			if (leave.getFromDate().getDayOfWeek() != DayOfWeek.SATURDAY
					&& leave.getFromDate().getDayOfWeek() != DayOfWeek.SUNDAY && leave.getNoOfDays() <= 2) {
				sum += leave.getNoOfDays();
			}
		}
		return sum;
	}
	



//	public void setUnusedLeavesFromEarlierMonths(Employee employee, int unusedLeavesFromLastMonth) {
//	    employee.setUnusedLeavesFromLastMonth(unusedLeavesFromLastMonth);
//	    employeeRepository.save(employee);
//	}
	
//	@Override
//	public void applyLeave(Integer empId, LocalDate startDate, LocalDate endDate, String reason)
//	        throws LeaveManagementSystemException {
//	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//	    if (optionalEmployee.isPresent()) {
//	        Employee employee = optionalEmployee.get();
//	        int daysApplied = calculateDaysApplied(startDate, endDate);
//	        
//	        // Get leaves applied in current month
//	        LocalDate firstDayOfMonth = LocalDate.now().withDayOfMonth(1);
//	        LocalDate lastDayOfMonth = LocalDate.now().withDayOfMonth(LocalDate.now().lengthOfMonth());
//	        List<Leave> leavesThisMonth = leaveRepository.findLeavesByEmployeeNoAndDateRange(
//	            empId, firstDayOfMonth, lastDayOfMonth);
//	        
//	        // Get unused leaves from last month
//	       // int unusedLeavesFromLastMonth = employee.getUnusedLeavesFromLastMonth();
//	        
//	        int unusedLeavesFromLastMonth = getUnusedLeavesFromLastMonth(empId);
//	        
//	        // Set unused leaves from earlier months
//	        employee.setUnusedLeavesFromEarlierMonths(unusedLeavesFromLastMonth);
//	        
//	        // Calculate total leaves applied in current month
//	        int leavesAppliedThisMonth = leavesThisMonth.stream()
//	            .mapToInt(Leave::getNoOfDays)
//	            .sum();
//	        
//	        // Check if leaves applied in current month exceed the limit
//	        if (leavesAppliedThisMonth + daysApplied > 2 + unusedLeavesFromLastMonth) {
//	            throw new LeaveManagementSystemException("Maximum " + (2 + unusedLeavesFromLastMonth) + " leaves can be applied in a month");
//	        }
//	        
//	        // Set unused leaves from last month
//	        employee.setUnusedLeavesFromLastMonth(Math.max(0, 2 - leavesAppliedThisMonth));
//	        
//	        Leave leave = new Leave();
//	        leave.setFromDate(startDate);
//	        leave.setToDate(endDate);
//	        leave.setStatus(Status.PENDING.toString());
//	        leave.setReason(reason);
//	        leave.setEmployee(employee);
//	        leaveRepository.save(leave);
//
//	    } else {
//	        throw new RuntimeException("Employee not found");
//	    }
//	}
	


	
	
//	@Override
//	public int getUnusedLeavesFromLastMonth(Integer empId) {
//	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//	    if (optionalEmployee.isPresent()) {
//	        Employee employee = optionalEmployee.get();
//	        LocalDate firstDayOfLastMonth = LocalDate.now().minusMonths(1).withDayOfMonth(1);
//	        LocalDate lastDayOfLastMonth = LocalDate.now().minusMonths(1).withDayOfMonth(LocalDate.now().minusMonths(1).lengthOfMonth());
//	        List<Leave> leavesLastMonth = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, firstDayOfLastMonth, lastDayOfLastMonth);
//	        int totalLeavesLastMonth = leavesLastMonth.stream().mapToInt(Leave::getNoOfDays).sum();
//	        int unusedLeavesLastMonth = 2 - totalLeavesLastMonth;
//	        return Math.max(0, unusedLeavesLastMonth);
//	    } else {
//	        throw new RuntimeException("Employee not found");
//	    }
//	}
	

	
//	@Override
//	public int getUnusedLeavesFromEarlierMonths(Integer empId) {
//	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//	    if (optionalEmployee.isPresent()) {
//	        Employee employee = optionalEmployee.get();
//	        int totalUnusedLeaves = 0;
//	        LocalDate today = LocalDate.now();
//	        for (int i = 1; i <= 12; i++) { // Check for all 12 months of the previous year
//	            LocalDate firstDayOfMonth = LocalDate.of(today.getYear() - 1, i, 1);
//	            LocalDate lastDayOfMonth = LocalDate.of(today.getYear() - 1, i, 1).withDayOfMonth(i < 12 ? i + 1 : 1).minusDays(1);
//	            List<Leave> leaves = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, firstDayOfMonth, lastDayOfMonth);
//	            int totalLeaves = leaves.stream().mapToInt(Leave::getNoOfDays).sum();
//	            int unusedLeaves = 2 - totalLeaves;
//	            if (unusedLeaves > 0) {
//	                totalUnusedLeaves += unusedLeaves;
//	            }
//	        }
//	        return totalUnusedLeaves;
//	    } else {
//	        throw new RuntimeException("Employee not found");
//	    }
//	}


	
	
//	@Override
//	public int getLeaveBalance(Integer empId, LocalDate date) throws LeaveManagementSystemException {
//	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//	    if (optionalEmployee.isPresent()) {
//	        Employee employee = optionalEmployee.get();
//	        int totalLeaves = employee.getLeaveEntitlement();
//	        LocalDate start = LocalDate.of(date.getYear(), 1, 1);
//	        LocalDate end = date.with(TemporalAdjusters.lastDayOfMonth());
//	        List<Leave> leaves = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, start, end);
//	        int usedLeaves = leaves.stream()
//	                .filter(l -> l.getStatus().equals("APPROVED") || l.getStatus().equals("PENDING"))
//	                .mapToInt(Leave::getNoOfDays).sum();
//	        int unusedLeaves = Math.max(0, totalLeaves - usedLeaves);
//	        return unusedLeaves;
//	    } else {
//	        throw new LeaveManagementSystemException("Employee not found");
//	    }
//	}
	
	@Override
	public int getLeaveBalance(Integer empId, LocalDate date) throws LeaveManagementSystemException {
	    Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
	    if (optionalEmployee.isPresent()) {
	        Employee employee = optionalEmployee.get();
	        int totalLeaves = employee.getLeaveEntitlement();
	        LocalDate start = LocalDate.of(date.getYear(), 1, 1);
	        LocalDate end = date.with(TemporalAdjusters.lastDayOfMonth());
	        List<Leave> leaves = leaveRepository.findLeavesByEmployeeNoAndDateRange(empId, start, end);
	        int usedLeaves = leaves.stream()
	                .filter(l -> l.getStatus().equals("APPROVED") || l.getStatus().equals("PENDING"))
	                .mapToInt(Leave::getNoOfDays).sum();
	        int unusedLeaves = Math.max(0, totalLeaves - usedLeaves);
	        return unusedLeaves;
	    } else {
	        throw new LeaveManagementSystemException("Employee not found");
	    }
	}

	
	

	


	






	
	
}
