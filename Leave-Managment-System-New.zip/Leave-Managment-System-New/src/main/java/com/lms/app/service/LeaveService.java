package com.lms.app.service;

import java.time.LocalDate;
import java.util.List;

import com.lms.app.entity.Leave;
import com.lms.app.entity.LeaveType;
import com.lms.app.exception.LeaveManagementSystemException;

public interface LeaveService {
	
	public void applyLeave(Integer empId, LocalDate startDate, LocalDate endDate, String reason) throws LeaveManagementSystemException;
	
	public void cancelLeave(Integer empId, Integer leaveId) throws LeaveManagementSystemException;
	
//	public List<Leave> getAllLeavesAvailable(Integer empId);
	public int calculateDaysApplied(LocalDate startDate, LocalDate endDate);
	
	public int getLeavesThisMonth(Integer empId);

//	int getUnusedLeavesFromLastMonth(Integer empId);

//	int getLeaveBalance(Integer empId);

	
	public int getLeaveBalance(Integer empId, LocalDate date) throws  LeaveManagementSystemException;

//	int getUnusedLeavesFromEarlierMonths(Integer empId);

}
