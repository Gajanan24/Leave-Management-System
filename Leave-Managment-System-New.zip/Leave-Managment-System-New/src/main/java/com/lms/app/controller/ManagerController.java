package com.lms.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lms.app.entity.Manager;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.service.ManagerService;

@RestController
public class ManagerController {
	@Autowired
	private ManagerService managerService;
	
	@PostMapping("/manager")
	public Manager registerManager(@RequestBody Manager manager) {
		return managerService.registerManager(manager);
		
	}
//	@PostMapping("/{empId}/leaveBalance")
//	public Integer updateLeavesAvailable(@PathVariable Integer empId, @RequestParam Integer leavesBalance ) throws LeaveManagementSystemException {
//		return managerService.updateLeaveBalance(empId, leavesBalance);
//		
//	}
//	@GetMapping("/leaveBalance/{empId}")
//	public Integer getLeaveBalance(@PathVariable ("empId") Integer empId) throws LeaveManagementSystemException {
//		return managerService.getLeaveBalance(empId);
//		
//	}

	
	
	

}
