package com.lms.app.entity;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.stream.Stream;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
public class Leave {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String reason;
    @JsonProperty(access = Access.READ_ONLY)
    private String status;
   // private LeaveType leaveType;
    @ManyToOne
    private Employee employee;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public LocalDate getFromDate() {
		return fromDate;
	}
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}
	public LocalDate getToDate() {
		return toDate;
	}
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
//	public LeaveType getLeaveType() {
//		return leaveType;
//	}
//	public void setLeaveType(LeaveType leaveType) {
//		this.leaveType = leaveType;
//	}
//	public int getNoOfDays() {
//	    return getNoOfDays();
//	}
	public int getNoOfDays() {
	    return (int) ChronoUnit.DAYS.between(fromDate, toDate.plusDays(1)) - (int) getWeekendDays();
	}
	private long getWeekendDays() {
	    return Stream.iterate(fromDate, date -> date.plusDays(1))
	            .limit(ChronoUnit.DAYS.between(fromDate, toDate.plusDays(1)))
	            .filter(date -> date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY)
	            .count();
	}
    
    
}
