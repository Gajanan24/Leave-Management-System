package com.lms.app.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.lms.app.entity.Leave;

@Repository
public interface LeaveRepository extends JpaRepository<Leave, Integer> {

	 @Query("SELECT l FROM Leave l WHERE l.employee.empId = :employeeId AND l.fromDate BETWEEN :startDate AND :endDate")
	   List<Leave> findLeavesByEmployeeNoAndDateRange(Integer employeeId, LocalDate startDate, LocalDate endDate);
	
	 @Query("SELECT l FROM Leave l WHERE l.employee.id = :empId AND l.fromDate < :endDate AND ((l.status = 'APPROVED' AND l.toDate >= :startDate) OR (l.status IN ('PENDING', 'REJECTED', 'CANCELLED')))")
	 List<Leave> findUnusedLeavesByEmployeeNoAndDateRange(@Param("empId") Integer empId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);


}
