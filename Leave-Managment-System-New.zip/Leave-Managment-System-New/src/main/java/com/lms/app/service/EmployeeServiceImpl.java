package com.lms.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.app.entity.Employee;
import com.lms.app.exception.LeaveManagementSystemException;
import com.lms.app.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee addEmployee) {
		
		return employeeRepository.save(addEmployee);
	}

	@Override
	public Employee getEmployeeById(Integer empid) throws LeaveManagementSystemException {
       Optional<Employee> optEmployee =employeeRepository.findById(empid);
       if(optEmployee.isEmpty())
    	   throw new LeaveManagementSystemException("Employee not found");
		return optEmployee.get();
		
		
	}

	@Override
	public Employee updatEmployee(Employee updateEmployee ) {
   
		return this.employeeRepository.save(updateEmployee);
	}

	@Override
	public Employee deletEmployeeById(Integer empid) {
      
		return null;
	}
	

}
