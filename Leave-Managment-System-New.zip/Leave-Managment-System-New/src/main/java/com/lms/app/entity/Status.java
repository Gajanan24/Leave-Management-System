package com.lms.app.entity;

public enum Status {
	APPROVED,REJECTED,PENDING,CANCELLED;
}
